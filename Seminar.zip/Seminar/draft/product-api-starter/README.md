# Product API — Live Coding Starter

This is the starter project for the **Java Spring Boot — 2-Hour Internal Knowledge Sharing** session
(slides: `Java Spring Boot.pptx`). The Maven project, dependencies, and `application.yml` are
already set up so session time goes to writing the API, not fighting the build.

## Prerequisites

- JDK 21+
- IntelliJ IDEA (recommended — it bundles Maven and has a built-in HTTP Client for the `.http`
  files), or any IDE plus Maven 3.6.3+ on your `PATH`

Tech stack for the demo: Java 21, Spring Boot 4.1.1, Spring Web MVC,
Spring Data JPA, Validation, H2 (in-memory), JUnit Jupiter 6 + Mockito.
The approved slide says **JUnit 5**; keep that wording in the deck. The project uses Jupiter 6
with the same `org.junit.jupiter` test API used in this demo. Dependency resolution still needs build verification.

## Run it

**IntelliJ:** open the project folder, wait for the Maven import to finish, open
`ProductApplication.java` and click the green ▶ next to `main`.

**Command line (PowerShell), if Maven is on your `PATH`:**

```powershell
mvn spring-boot:run
```

The app starts on `http://localhost:8080` (look for `Tomcat started on port 8080` in the console).
There are no endpoints yet — that's what we're building. `main` has no active profile configured;
`dev` becomes the default at `step-10-profiles`. H2 is in-memory and loses data after restart.
Do not run the seed against the empty starter: POST is available from `step-05-post-endpoint`.

## Static review status

The 2026-09-27 review read the approved DOC and all 16 slides, then inspected `main`, `solution`
and all 12 step tags. **No build, tests, app execution, or downloads were performed.**
See [the Vietnamese review report](REVIEW-20260927.md) for findings and items needing build verification.
IDE menu names and shortcuts assume the Windows default keymap; confirm HTTP Client availability
in the installed IntelliJ edition before the session, or use Postman.

## Try the API

- [`demo-requests.http`](demo-requests.http) — the requests used in the session, in demo order.
  In IntelliJ, click the ▶ next to each request. Request 1 stores the new product's `id` so
  request 3 can reuse it.
- [`seed.http`](seed.http) — eight extra products so pagination and sorting have something to show.
  Run it once after each restart (IntelliJ: ▶▶ "Run all requests in file").

Postman works too. In Windows PowerShell 5.1, `curl` is an alias for `Invoke-WebRequest` — call `curl.exe`
explicitly to see status codes and error bodies:

```powershell
curl.exe -i http://localhost:8080/api/products/99999
```

## Live-coding checklist and checkpoint tags

Every step of the session is a Git tag. If you fall behind, compare your code with a tag
(IntelliJ: *Git → Compare with Branch or Tag…*) or jump straight to it.

| Tag | What it adds |
|---|---|
| `step-01-entity` | `entity/Product.java` (`id`, `name`, `sku`, `price`, `active`) |
| `step-02-dtos` | `dto/CreateProductRequest.java` (validation) and `dto/ProductResponse.java` |
| `step-03-repository` | `repository/ProductRepository.java` (`JpaRepository` + `existsBySku`) |
| `step-04-service` | `service/ProductService.java` — `create` + mapping to `ProductResponse` |
| `step-05-post-endpoint` | `controller/ProductController.java` — `POST /api/products` · **checkpoint A** |
| `step-06-error-handling` | `exception/ApiError.java` + `GlobalExceptionHandler` for validation errors (`400`) |
| `step-07-get-by-id` | `GET /api/products/{id}` + `ProductNotFoundException` (`404`) · **checkpoint B** |
| `step-08-pagination` | `GET /api/products?page=0&size=10&sort=name,asc` |
| `step-09-duplicate-sku` | *(optional)* `DuplicateSkuException` → `409 DUPLICATE_SKU` |
| `step-10-profiles` | `application-dev.yml` / `application-prod.yml` + a debug log line · **checkpoint C** |
| `step-11-unit-test` | `ProductServiceTest` (Mockito) |
| `step-12-integration-test` | `ProductApiIntegrationTest` (`@SpringBootTest` + `MockMvc`) |

The `solution` branch is the finished project, including a few extra tests.

## Stuck? Jump to a checkpoint

```powershell
git stash -u
git checkout step-07-get-by-id
```

`git stash -u` puts your own changes aside (bring them back later with `git stash pop`). Git prints
a *detached HEAD* note after the checkout — that is fine for following along. Then restart the app
and re-run `seed.http`. To go back to the starting point: `git checkout main`.

## Reproduce the pagination examples

Use `step-08-pagination` or later. Start with a fresh app process using the default H2 in-memory
database and no external DB overrides. Run `seed.http` **once** (8 successful creates), then
request **#1 once** (1 successful create): **9 products**, so `size=5` gives `totalPages=2`.
Repeated seeding produces duplicate SKU errors. Request #3 uses the ID saved by #1; after a restart,
create again before expecting #3 to return 200. Request #9 intentionally demonstrates an unhandled error.

Skipping the live coding of step 09 does not remove it from checkpoint C: stash unfinished work
and switch to `step-10-profiles` before testing, even if the manually added profiles already work.
Checkpoint A is `step-05-post-endpoint`, B is `step-07-get-by-id`, and C is `step-10-profiles`.
The existing step tags are preserved; README and HTTP-comment clarifications live on branch tips only.

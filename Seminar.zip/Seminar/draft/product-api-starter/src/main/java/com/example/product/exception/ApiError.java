package com.example.product.exception;

import java.time.Instant;

public record ApiError(
        String code,
        String message,
        Instant timestamp
) {
}

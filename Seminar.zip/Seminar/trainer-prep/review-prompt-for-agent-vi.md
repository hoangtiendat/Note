# Prompt: Review script live demo và product-api-starter theo tài liệu đã delivery

Bạn là reviewer cho một buổi **sharing nội bộ về Java Spring Boot**. Nhiệm vụ: review rồi sửa **đúng
hai thứ** sao cho khớp với hai tài liệu đã giao cho Training Team.

## 1. Phạm vi

**Được sửa (chỉ hai thứ này):**

1. `C:\Data\Seminar\spring-boot-live-demo-script-vi.md` — script live demo (tiếng Việt).
2. `C:\Data\Seminar\product-api-starter\` — project demo (git repo).

**Nguồn chuẩn — CHỈ ĐỌC, tuyệt đối không sửa, không lưu đè, không đổi tên:**

- `C:\Data\Seminar\Java Spring Boot Training.doc`
- `C:\Data\Seminar\Java Spring Boot.pptx`

Hai file này đã được duyệt và giao cho Training Team. Khi script hoặc code khác với chúng thì **sửa
script/code cho khớp với chúng**, không bao giờ làm ngược lại. File `~$Java Spring Boot.pptx` là file
lock của PowerPoint, bỏ qua nó.

**Không sửa** các file trong `C:\Data\Seminar\trainer-prep\`. Nếu thấy chúng lệch với script sau khi
bạn sửa (ví dụ `04-cheat-sheet-vi.md`), chỉ **liệt kê trong báo cáo**.

## 2. Ràng buộc bắt buộc

- **Không build, không chạy test, không tải gì.** Không chạy `mvn`, `mvnw`, Gradle, không tải
  dependency, JDK hay binary nào, và không tìm cách lách (không dùng Docker, không tải jar tay, không
  dùng repo khác). Mọi kiểm tra đều làm **tĩnh**: đọc code, đọc `pom.xml`, so API/package theo kiến
  thức của bạn. Chỗ nào không chắc thì ghi "cần verify khi build" trong báo cáo, không được đoán.
- **Git: chỉ commit local, không bao giờ `push`.** Không force-push, không xóa branch, không xóa tag.
- **Trước khi sửa script**, copy một bản vào
  `C:\Data\Seminar\trainer-prep\_backup\spring-boot-live-demo-script-vi.before-review-<yyyymmdd>.md`.
- **Trước khi sửa repo**, tạo tag backup trỏ vào commit hiện tại của mỗi branch bạn sửa (theo kiểu đã
  có: `backup/main-before-…`, `backup/solution-before-…`).

## 3. Bối cảnh project

- Repo `product-api-starter`:
  - Branch `main` là bản khung để live-coding.
  - Branch `solution` là bản hoàn chỉnh, có thêm test cho 400/404/409.
  - 12 tag là từng bước demo: `step-01-entity`, `step-02-dtos`, `step-03-repository`,
    `step-04-service`, `step-05-post-endpoint`, `step-06-error-handling`, `step-07-get-by-id`,
    `step-08-pagination`, `step-09-duplicate-sku`, `step-10-profiles`, `step-11-unit-test`,
    `step-12-integration-test`.
- **Stack:**
  - Spring Boot 4.1.1, Spring Framework 7, JDK 21, H2 in-memory.
  - JUnit Jupiter 6 và Mockito.
  - Test starter là `spring-boot-starter-webmvc-test`.
  - `@AutoConfigureMockMvc` nằm ở package `org.springframework.boot.webmvc.test.autoconfigure` (Boot 4, khác Boot 3).
- **Domain:**
  - Entity `Product(id, name, sku, price, active)`.
  - DTO `CreateProductRequest` và `ProductResponse` (dạng record).
  - `ProductRepository` (có `existsBySku`), `ProductService`, `ProductController`.
  - `GlobalExceptionHandler`, `ApiError(code, message, timestamp)`, `ProductNotFoundException`, `DuplicateSkuException`.
  - Controller dùng `@PageableDefault(size = 10, sort = "name")`.
  - Có profile `dev` / `prod`.
  - Test: `ProductServiceTest` (Mockito) và `ProductApiIntegrationTest` (MockMvc).
- **Các file dùng trong demo:** `demo-requests.http` có request #1–#10, `seed.http` có 8 sản phẩm. Sau
  seed và request #1 thì có tổng **9 sản phẩm**.
- **Slide ghi "JUnit 5"** nhưng project dùng JUnit Jupiter 6. **Giữ nguyên như vậy**: script đã có
  câu giải thích, đừng hạ version và đừng sửa slide.

## 4. Việc cần làm

### 4.1 Đọc nguồn chuẩn

- **PPTX:** nội dung nhiều slide nằm trong **ảnh**. Hãy giải nén (pptx là file zip) vào một thư mục
  tạm **ngoài** `C:\Data\Seminar`, rồi xem `ppt/slides/*.xml` và `ppt/media/*`. Cần nắm từng slide
  (16 slide) ghi gì, theo đúng thứ tự.
- **DOC:** là file `.doc` định dạng cũ. Hãy trích text bằng công cụ sẵn có trên máy (ví dụ Word COM
  qua PowerShell, lưu *bản sao* sang .txt ở thư mục tạm), không lưu đè file gốc.

### 4.2 Review script `spring-boot-live-demo-script-vi.md`

**a. Bám slide, đủ ý, đúng thứ tự.** Mỗi slide phải có:

- Một dòng **`Trên slide:`** chép đúng nội dung slide, theo thứ tự.
- Một đoạn `[NÓI]` đi lần lượt qua **tất cả** các ý đó, dùng chính cụm từ tiếng Anh trên slide làm
  mốc.

Không được "chỉ chọn vài ý". Ví dụ lỗi cũ đã sửa: slide 6 *Why constructor injection?* có 5 ý
(*Dependencies are explicit* · *Easier to test* · *Fields can be immutable (final)* · *Easier to
reason about* · ✗ *Avoid field injection as the default*), nhưng script cũ chỉ nói 2 ý. Hãy kiểm tra
kỹ các slide nhiều ý:

- Slide 5: 6 ý bên trái, cộng *Under the hood*. Khối start.spring.io (Explore) ở slide 5 là **có chủ đích**: không có trên slide, minh họa ý *Dependency management*; không xóa. Chỉ kiểm tra nó vẫn nằm sau ý thứ 6 và trước `[MỞ] ProductApplication.java`, Package name là `com.example.product`, không hướng dẫn bấm GENERATE, và slide 5 vẫn vừa 5 phút.
- Slide 7: cây package, cộng 3 *Layer Responsibilities*.
- Slide 8: entity, 3 *Core APIs*, *Tech Stack*.
- Slide 9: sơ đồ và 4 câu.
- Slide 10: sơ đồ và tagline.
- Slide 11: danger/safe path, 6 *key risks*, 2 *pro-tips*.
- Slide 12: 3 mức config, mũi tên *override/runtime*, 4 ý.
- Slide 13: 5 dòng mỗi bên, kể cả *Tools*.
- Slide 14: bảng *Mistake / Bad / Better*.
- Slide 15: 5 tiêu đề và câu phụ của từng tiêu đề.

**b. Không vượt phạm vi.** Nội dung nói phải nằm trong phạm vi của `.doc` và slide. Kiến thức
thêm chỉ được để trong "Ghi chú cho người trình bày" hoặc phụ lục, không đưa vào `[NÓI]` chính. Nếu
`.doc` có mục mà script bỏ sót, báo lại và bổ sung nếu vừa thời lượng.

**c. Giọng nói.** Đây là buổi **sharing knowledge giữa đồng nghiệp cùng công ty** (2 giờ,
09:30–11:30, qua Zoom), **không phải lớp học**. Người dùng đã phàn nàn script cũ "sách giáo khoa",
phần mở đầu không tự nhiên. Yêu cầu:

- Xưng "mình", gọi "mọi người" / "anh chị em". Không dùng "lớp", "học viên", "giảng", "bài học",
  "kinh điển", "Mục tiêu một câu".
- Câu ngắn, như đang nói chuyện. Được kể trải nghiệm thật ("team mình từng…", "chắc nhiều người từng
  gặp…"), và mời góp ý ("anh chị em làm lâu hơn mình cứ bổ sung").
- Đọc to lên phải thấy trôi, không giống văn viết.

**d. Thuật ngữ: giữ tiếng Anh, không dịch gượng.** Người dùng nói rõ các từ chuyên ngành dịch sang
tiếng Việt "rất kỳ". Dùng đúng từ mà dev Việt Nam hay nói:

| Không dùng | Dùng |
|---|---|
| tầng (service/controller) | layer, service layer |
| ranh giới / biên | boundary, *at the boundary* / *at the edge* |
| hợp đồng (API/lỗi) | API contract, error contract |
| ghi đè | override |
| bất biến | immutable |
| ánh xạ | map |
| khóa chính, ràng buộc | primary key, constraint |
| giao dịch | transaction |
| phân trang, trang | pagination, page |
| sắp xếp | sort / sorting |
| biến môi trường | environment variable |
| trong bộ nhớ | in-memory |
| định dạng (lỗi/response) | format |
| khởi động app | start app |
| xác thực, phân quyền | authentication, authorization |
| tiêm phụ thuộc, phụ thuộc | Dependency Injection, dependency |
| ngoại lệ | exception |

Từ tiếng Việt tự nhiên thì giữ nguyên (ví dụ "lỗi", "dữ liệu", "bảng", "cấu hình" khi nói chung
chung).

**e. Khớp với code.** Kiểm tra từng chỗ script khẳng định điều gì đó về code, đối chiếu với đúng tag
tương ứng:

- code block, import, tên package, annotation;
- JSON kết quả mong đợi, message lỗi (ví dụ
  `name: must not be blank, price: must be greater than 0, sku: must not be blank`);
- status code, thứ tự sort của request #5 / #6 / #7, `totalPages = 2`;
- câu SQL trong console, dòng log profile;
- phím tắt IntelliJ, số request trong `.http`;
- tên tag ở mỗi CHECKPOINT (A = `step-05`, B = `step-07`, C = `step-10`, đã gồm bước 409).

**f. Timeline và cấu trúc.**

- Tổng thời gian khớp 2 giờ, và timeline khớp với heading từng phần.
- Cột "Slide" trong timeline khớp với slide thật. Riêng bước 409 tùy chọn **không có slide riêng**,
  cột này ghi "—" (đã quyết định, giữ nguyên).
- Các anchor nội bộ (`](#...)`) phải trỏ tới heading có thật.

**g. Giữ nguyên:** định dạng legend (`[NÓI]`, `[GÕ]`, `[SINH]`, `[DÁN]`, `[CHẠY]`, `[MỞ]`,
`[DỰ ĐOÁN]`, `Trên slide`), các CHECKPOINT, kế hoạch dự phòng, Phụ lục A–E. Chỉ sửa khi sai hoặc
lệch nguồn chuẩn.

### 4.3 Review `product-api-starter`

- Code ở `main`, `solution` và từng tag phải khớp đúng với những gì slide, `.doc` và script mô tả:
  tên class, package (`com.example.product.{controller,dto,entity,exception,repository,service}`),
  field, endpoint, status code, format `ApiError`, profile, test.
- Mỗi tag phải là trạng thái mà script nói người trình bày sẽ có tại bước đó, và phải compile được
  **về mặt tĩnh**: import đúng, không thiếu class.
- README, `.http` và file cấu hình phải khớp với script.
- Tìm bug, import sai kiểu Boot 3, API deprecated/không tồn tại ở Boot 4.1 / Spring 7, và test không
  thể pass (ví dụ SKU trùng giữa các test có dùng chung context).
- **Sửa code ở một bước giữa chừng sẽ làm lệch các tag phía sau.** Không tự ý dời hay tạo lại tag. Nếu
  cần, hãy mô tả phương án (commit nào, tag nào cần dời, ảnh hưởng gì) trong báo cáo và **dừng lại hỏi
  người dùng** trước khi làm.

## 5. Cách làm và báo cáo

1. Đọc hết nguồn chuẩn → đọc script → đọc repo, cả `main`, `solution` và các tag (dùng `git show
   <tag>:<path>` hoặc `git diff <tagA> <tagB>`, không checkout làm bẩn working tree).
2. Lập danh sách phát hiện. Mỗi mục gồm: mức độ (**Blocker / Major / Minor / Tone**), vị trí
   (`file:line` hoặc `tag:path`), nguồn chuẩn nói gì, hiện tại là gì, đề xuất sửa.
3. Tự phản biện từng phát hiện một lần trước khi sửa: có thật sự lệch với slide/doc không, hay chỉ là
   sở thích? Bỏ những mục không có căn cứ.
4. Sửa script (sau khi backup). Sửa repo bằng commit local rõ ràng, trừ các việc phải hỏi ở mục 4.3.
5. Báo cáo cuối **bằng tiếng Việt** (thuật ngữ giữ tiếng Anh), gồm:
   - những gì đã sửa;
   - những gì đề xuất nhưng chưa sửa, và vì sao;
   - những chỗ "cần verify khi build";
   - danh sách file trong `trainer-prep/` có thể bị lệch;
   - xác nhận rõ ràng: không đụng pptx/doc, không build/tải gì, không push.
